using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Cryptography.X509Certificates;

namespace CalculatorTest
{
    [TestClass]
    public class CalcTest
    {
        [TestMethod]
        public void Sum_shouldReturnSameValue()
        {
            // Arrange
            int a = 28;
            int b = 22;
            int expected = 50;

            // Act
            int actual = Calc.Sum(a, b);

            // Assert
            Assert.AreEqual(expected, actual); 
        }


    }
}